<?php
/**
Dev Mosab Irwished
eng.mosabirwished@gmail.com
WhatsApp +970592879186
 */
namespace App\Traits;

use Carbon\Carbon;

trait ActionButtons
{


}
