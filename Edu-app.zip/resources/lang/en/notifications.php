<?php
/*
 * Dev Mosab Irwished
eng.mosabirwished@gmail.com
WhatsApp +970592879186
*/

return
    [
        'Ready order' => 'Ready order',
        'There is a new Order need delivery' => 'There is a new Order need delivery',
        'Accept order' => 'Accept order',
        'Your order accepted' => 'Your order accepted',
        'On Progress Order order' => 'On Progress Order order',
        'Your order On Progress' => 'Your order On Progress',
        'Driver Accept order' => 'Driver Accept order',
        'Your order accepted from driver' => 'Your order accepted from driver',
        'Driver On Way order' => 'Driver On Way order',
        'Your order On Way from' => 'Your order On Way from',
        'Driver Completed order' => 'Driver Completed order',
        'Your order was completed' => 'Your order was completed',
        'Driver On Way Done order' => 'Driver On Way Done order',
        'Your order On Way Done' => 'Your order On Way Done',
        'Canceled order' => 'Canceled order',
        'Your order Canceled' => 'Your order Canceled',
        'Add New Balance' => 'Add New Balance',
        'Admin Charge your wallet with a new balance' => 'Admin Charge your wallet with a new balance',
        'User order' => 'User order',
        'Your order Rated' => 'Your order Rated',
        'Client rated you on order' => 'Client rated you on order :uuid',
        'Driver rated you on order' => 'Driver rated you on order :uuid',


  'Client rated you on Ad' => 'Client rated you on Ad',
  
  'You have New order' => 'You have New order',  
  'New Message from' => 'New Message from',
];
