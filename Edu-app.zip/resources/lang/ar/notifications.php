<?php
/*
Dev Mosab Irwished
eng.mosabirwished@gmail.com
WhatsApp +970592879186
*/

return
[
  'Driver On Way Done order' => 'Driver On Way Done order',
  'Your order On Way Done' => 'Your order On Way Done',
  'Canceled order' => 'Canceled order',
  'Your order Canceled' => 'Your order Canceled',
  'User order' => 'User order',
  'Your order Rated' => 'Your order Rated',
    'new_order_notification' => 'طلب جديد :uuid',
    'Add New Balance' => 'تم اضافة رصيد جديد الى محفظتك',
    'Admin Charge your wallet with a new balance' => 'تم اضافة رصيد بقيمة :amount الى رصيد المحفظة الخاص بك ',
    'Accept order' => 'تم قبول طلبك',
    'Your order accepted' => 'تم قبول طلبك من قبل المزود',
    'On Progress Order order' => 'طلبك قيد التجهيز',
    'Your order On Progress' => 'طلبك قيد التجهيز عند المزود',
    'Ready order' => 'طلبك جاهز',
    'There is a new Order need delivery' => 'هناك طلب جديد',
    'Driver Accept order' => 'السائق قبل الطلبية',
    'Your order accepted from driver' => 'تم قبول طلبك من قبل المندوب',
    'Driver On Way order' => 'المندوب في الطريق اليك',
    'Your order On Way from' => 'المندوب في الطريق اليك',
    'Driver Completed order' => 'تم اكمال التوصيلة من قبل المندوب',
    'Your order was completed' => 'تم اكمال طلبك',
    'New Offer' => 'هناك عرض جديد',
    'Driver Canceled order' => 'المندوب لغى توصيل طلبك',
    'Your order was Canceled from driver' => 'تم الغاء توصيل طلبك من قبل المندوب',
    'Driver Rate Client' => 'تم تقييم الطلبية من قبل المندوب',
    'New order' => 'هناك طلب جديد',
    'Client Rate Branch' => 'تم تقييم الطلبية من قبل العميل',
    'Client Rate Driver' => 'تم تقييم التوصيلة من قبل العميل',
  'Client rated you on order' => 'تم تقييمك من قبل العميل على الطلبية :uuid',
  'Driver rated you on order' => 'تم تقييمك من قبل المندوب على الطلبية :uuid',
  'Client rated you on Ad' => 'Client rated you on Ad',
  
  'You have New order' => 'You have New order',  
  'New Message from' => 'New Message from',
];
